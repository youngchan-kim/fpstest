using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// MoveCamera.cs - 카메라 이동 최적화 및 성능 개선
// 기존 코드:
// - Update()에서 과도한 연산 수행으로 성능 저하 발생
// - 카메라 이동 로직이 비효율적으로 구현됨
// 변경된 코드:
// - LateUpdate()를 활용하여 부드러운 카메라 이동 구현
// - 카메라 이동 및 회전 계산을 최소화하여 성능 최적화
// 주요 이점:
// - 성능 최적화 및 FPS 유지율 향상
// - 코드 가독성 향상 및 유지보수 용이

public class MoveCamera : MonoBehaviour
{
    public Transform target;
    public float smoothSpeed = 0.125f;
    public Vector3 offset;

    void LateUpdate()
    {
        Vector3 desiredPosition = target.position + offset;
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
        transform.position = smoothedPosition;
        transform.LookAt(target);
    }
}